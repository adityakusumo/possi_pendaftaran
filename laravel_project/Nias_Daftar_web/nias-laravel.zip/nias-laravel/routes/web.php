<?php

use App\Http\Controllers\NiasController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| NIAS Registration Routes
|--------------------------------------------------------------------------
|
| GET    /               → redirect to /nias
| GET    /nias           → index   – list + search
| GET    /nias/create    → create  – registration form
| POST   /nias           → store   – save (auto TGLDAFTAR & EXPIRED)
| GET    /nias/{id}      → show    – detail view
| GET    /nias/{id}/edit → edit    – edit form
| PUT    /nias/{id}      → update  – save edits
| DELETE /nias/{id}      → destroy – delete
|
*/

Route::get('/', fn () => redirect()->route('nias.index'));

Route::resource('nias', NiasController::class);

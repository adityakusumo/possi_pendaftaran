@extends('layouts.app')
@section('title','Edit Data NIAS')

@section('content')
<div class="card page-card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">
            <i class="bi bi-pencil-square me-2"></i>Edit Data NIAS
            <span class="fw-normal opacity-75 ms-1">— {{ $nias->NAMA }}</span>
        </h5>
        <a href="{{ route('nias.show', $nias) }}" class="btn btn-light btn-sm">
            <i class="bi bi-arrow-left me-1"></i>Kembali
        </a>
    </div>

    <div class="card-body p-4">
        <form method="POST" action="{{ route('nias.update', $nias) }}" autocomplete="off">
            @csrf
            @method('PUT')
            @include('nias._form')

            <div class="d-flex justify-content-end gap-2">
                <a href="{{ route('nias.show', $nias) }}" class="btn btn-outline-secondary">
                    <i class="bi bi-x-circle me-1"></i>Batal
                </a>
                <button type="submit" class="btn btn-warning px-4 text-dark fw-semibold">
                    <i class="bi bi-save me-1"></i>Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
$(function () {
    $('#NAMACLUB').select2({ theme:'bootstrap-5', placeholder:'— Pilih Klub —', allowClear:true, width:'100%' });
    $('#NAMAKOTADOM').select2({ theme:'bootstrap-5', placeholder:'— Pilih Kota/Kab —', allowClear:true, width:'100%' });

    const clubMeta = @json(
        collect(\App\Models\Nias::$clubLookup)->map(fn($v) => [
            'kdjenis'=>$v[0],'jenis'=>$v[1],'kdkota'=>$v[2],'namakota'=>$v[3]
        ])
    );

    function updateClubInfo() {
        const name = $('#NAMACLUB').val();
        const box  = $('#clubInfoBox');
        if (name && clubMeta[name]) {
            const m = clubMeta[name];
            const tipe = m.jenis === 'KOTA' ? 'Kota' : 'Kabupaten';
            box.html(`
                <span class="badge rounded-pill text-bg-info me-1">
                    <i class="bi bi-geo-alt-fill me-1"></i>${tipe} ${m.namakota}
                </span>
                <span class="badge rounded-pill text-bg-secondary">Kode: ${m.kdkota}</span>
            `);
        } else { box.html(''); }
    }

    $('#NAMACLUB').on('change', updateClubInfo);
    updateClubInfo();

    $('input[name="NAMA"], input[name="TEMPATLAHIR"]').on('input', function () {
        const pos = this.selectionStart;
        this.value = this.value.toUpperCase();
        this.setSelectionRange(pos, pos);
    });
});
</script>
@endpush

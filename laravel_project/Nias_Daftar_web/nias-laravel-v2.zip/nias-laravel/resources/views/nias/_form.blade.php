{{--
    Shared form partial — used by nias/create.blade.php and nias/edit.blade.php
    Expects: $clubs (array), $domisilis (array), $nias (optional Nias model)
--}}

@if($errors->any())
<div class="alert alert-danger alert-dismissible fade show shadow-sm">
    <i class="bi bi-exclamation-triangle-fill me-2"></i>
    <strong>Terdapat kesalahan input:</strong>
    <ul class="mb-0 mt-1 ps-3">
        @foreach($errors->all() as $e)
            <li>{{ $e }}</li>
        @endforeach
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

{{-- ══════════════════════════════════════
     1. DATA PRIBADI
══════════════════════════════════════ --}}
<div class="card section-card mb-4">
    <div class="card-header py-2 px-3">
        <span class="fw-bold text-primary small">
            <i class="bi bi-person-badge me-1"></i>DATA PRIBADI
        </span>
    </div>
    <div class="card-body row g-3">

        {{-- Nama --}}
        <div class="col-md-8">
            <label class="form-label" for="NAMA">
                Nama Lengkap <span class="text-danger">*</span>
            </label>
            <input type="text" id="NAMA" name="NAMA"
                   class="form-control text-uppercase @error('NAMA') is-invalid @enderror"
                   value="{{ old('NAMA', $nias->NAMA ?? '') }}"
                   placeholder="Masukkan nama lengkap" required maxlength="100">
            @error('NAMA')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        {{-- Gender --}}
        <div class="col-md-4">
            <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
            <select name="GENDER" class="form-select @error('GENDER') is-invalid @enderror" required>
                <option value="L" {{ old('GENDER', $nias->GENDER ?? 'L') === 'L' ? 'selected' : '' }}>
                    Laki-laki
                </option>
                <option value="P" {{ old('GENDER', $nias->GENDER ?? '') === 'P' ? 'selected' : '' }}>
                    Perempuan
                </option>
            </select>
            @error('GENDER')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        {{-- Tempat Lahir --}}
        <div class="col-md-5">
            <label class="form-label">Tempat Lahir <span class="text-danger">*</span></label>
            <input type="text" name="TEMPATLAHIR"
                   class="form-control text-uppercase @error('TEMPATLAHIR') is-invalid @enderror"
                   value="{{ old('TEMPATLAHIR', $nias->TEMPATLAHIR ?? '') }}"
                   placeholder="Kota / kabupaten tempat lahir" required maxlength="100">
            @error('TEMPATLAHIR')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        {{-- Tanggal Lahir --}}
        <div class="col-md-4">
            <label class="form-label">Tanggal Lahir <span class="text-danger">*</span></label>
            <input type="date" name="TGLLAHIR"
                   class="form-control @error('TGLLAHIR') is-invalid @enderror"
                   value="{{ old('TGLLAHIR', isset($nias->TGLLAHIR) ? $nias->TGLLAHIR->format('Y-m-d') : '') }}"
                   max="{{ date('Y-m-d', strtotime('-1 day')) }}" required>
            @error('TGLLAHIR')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        {{-- NIK --}}
        <div class="col-md-6">
            <label class="form-label">NIK (16 digit)</label>
            <input type="text" name="NIK" maxlength="16"
                   class="form-control @error('NIK') is-invalid @enderror"
                   value="{{ old('NIK', $nias->NIK ?? '') }}"
                   placeholder="Nomor Induk Kependudukan (opsional)"
                   inputmode="numeric" pattern="[0-9]{16}">
            @error('NIK')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        {{-- Email --}}
        <div class="col-md-6">
            <label class="form-label">Email</label>
            <input type="email" name="EMAIL"
                   class="form-control @error('EMAIL') is-invalid @enderror"
                   value="{{ old('EMAIL', $nias->EMAIL ?? '') }}"
                   placeholder="email@contoh.com (opsional)" maxlength="100">
            @error('EMAIL')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

    </div>
</div>

{{-- ══════════════════════════════════════
     2. KLUB
══════════════════════════════════════ --}}
<div class="card section-card mb-4">
    <div class="card-header py-2 px-3">
        <span class="fw-bold text-primary small">
            <i class="bi bi-people me-1"></i>DATA KLUB / PERGURUAN
        </span>
    </div>
    <div class="card-body row g-3">

        <div class="col-md-9">
            <label class="form-label" for="NAMACLUB">
                Nama Klub <span class="text-danger">*</span>
            </label>
            <select name="NAMACLUB" id="NAMACLUB"
                    class="form-select @error('NAMACLUB') is-invalid @enderror" required>
                <option value="">— Ketik atau pilih klub —</option>
                @foreach($clubs as $club)
                    <option value="{{ $club }}"
                        {{ old('NAMACLUB', $nias->NAMACLUB ?? '') === $club ? 'selected' : '' }}>
                        {{ $club }}
                    </option>
                @endforeach
            </select>
            @error('NAMACLUB')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

        {{-- Club info pill (JS-populated) --}}
        <div class="col-12">
            <div id="clubInfoBox"></div>
        </div>

    </div>
</div>

{{-- ══════════════════════════════════════
     3. DOMISILI
══════════════════════════════════════ --}}
<div class="card section-card mb-4">
    <div class="card-header py-2 px-3">
        <span class="fw-bold text-primary small">
            <i class="bi bi-geo-alt me-1"></i>DOMISILI DI JAWA TIMUR
        </span>
    </div>
    <div class="card-body row g-3">

        <div class="col-md-4">
            <label class="form-label">Provinsi</label>
            <input type="text" class="form-control bg-light" value="JAWA TIMUR" disabled>
        </div>

        <div class="col-md-8">
            <label class="form-label" for="NAMAKOTADOM">
                Kota / Kabupaten <span class="text-danger">*</span>
            </label>
            <select name="NAMAKOTADOM" id="NAMAKOTADOM"
                    class="form-select @error('NAMAKOTADOM') is-invalid @enderror" required>
                <option value="">— Pilih Kota / Kabupaten —</option>
                @foreach($domisilis as $dom)
                    <option value="{{ $dom }}"
                        {{ old('NAMAKOTADOM', $nias->NAMAKOTADOM ?? '') === $dom ? 'selected' : '' }}>
                        {{ $dom }}
                    </option>
                @endforeach
            </select>
            @error('NAMAKOTADOM')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>

    </div>
</div>

{{-- ══════════════════════════════════════
     4. INFO OTOMATIS
══════════════════════════════════════ --}}
<div class="rounded p-3 mb-4 border"
     style="background:#f0f5ff; border-color:#c5d8ff !important;">
    <p class="mb-2 small fw-semibold text-primary">
        <i class="bi bi-info-circle me-1"></i>Diisi otomatis oleh sistem:
    </p>
    <div class="row g-2 small">
        <div class="col-sm-4">
            <span class="text-secondary">Tanggal Daftar:</span>
            <strong class="ms-1">{{ now()->format('d/m/Y') }}</strong>
        </div>
        <div class="col-sm-4">
            <span class="text-secondary">Masa Berlaku s/d:</span>
            <strong class="ms-1 text-success">{{ now()->addYears(2)->format('d/m/Y') }}</strong>
        </div>
        <div class="col-sm-4">
            <span class="text-secondary">Status:</span>
            <span class="badge bg-success ms-1">AKTIF</span>
        </div>
    </div>
</div>

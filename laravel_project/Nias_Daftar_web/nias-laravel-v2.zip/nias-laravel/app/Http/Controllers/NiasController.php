<?php

namespace App\Http\Controllers;

use App\Models\Nias;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class NiasController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    // -------------------------------------------------------------------------
    // INDEX — hanya tampilkan data atlet milik user yang login
    // -------------------------------------------------------------------------
    public function index(Request $request)
    {
        $query = Nias::where('user_id', Auth::id())
                     ->orderBy('created_at', 'desc');

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('NAMA',    'like', "%{$s}%")
                  ->orWhere('NONIAS',   'like', "%{$s}%")
                  ->orWhere('NAMACLUB', 'like', "%{$s}%");
            });
        }

        $records = $query->paginate(20)->withQueryString();

        return view('nias.index', compact('records'));
    }

    // -------------------------------------------------------------------------
    // CREATE
    // -------------------------------------------------------------------------
    public function create()
    {
        $clubs     = array_keys(Nias::$clubLookup);
        sort($clubs);
        $domisilis = array_keys(Nias::$domisiliLookup);
        sort($domisilis);

        return view('nias.create', compact('clubs', 'domisilis'));
    }

    // -------------------------------------------------------------------------
    // STORE
    // -------------------------------------------------------------------------
    public function store(Request $request)
    {
        $validated = $request->validate([
            'NAMA'        => 'required|string|max:100',
            'GENDER'      => 'required|in:L,P',
            'TGLLAHIR'    => 'required|date|before:today',
            'TEMPATLAHIR' => 'required|string|max:100',
            'NIK'         => 'nullable|digits:16',
            'EMAIL'       => 'nullable|email|max:100',
            'NAMACLUB'    => 'required|string|max:100',
            'NAMAKOTADOM' => 'required|string|max:100',
        ]);

        $clubInfo = Nias::$clubLookup[$validated['NAMACLUB']] ?? null;
        $clubCode = Nias::$clubCodeLookup[$validated['NAMACLUB']] ?? null;
        $domInfo  = Nias::$domisiliLookup[$validated['NAMAKOTADOM']] ?? null;

        $today   = Carbon::today();
        $expired = $today->copy()->addYears(2);

        DB::transaction(function () use ($validated, $clubInfo, $clubCode, $domInfo, $today, $expired) {
            Nias::create([
                'user_id'     => Auth::id(),
                'NAMA'        => strtoupper(trim($validated['NAMA'])),
                'GENDER'      => $validated['GENDER'],
                'TGLLAHIR'    => $validated['TGLLAHIR'],
                'TEMPATLAHIR' => strtoupper(trim($validated['TEMPATLAHIR'])),
                'NIK'         => $validated['NIK']   ?? null,
                'EMAIL'       => $validated['EMAIL'] ?? null,
                'NAMACLUB'    => $validated['NAMACLUB'],
                'KDCLUB'      => $clubCode,
                'KDJENIS'     => $clubInfo[0] ?? null,
                'JENIS'       => $clubInfo[1] ?? null,
                'KDKOTA'      => $clubInfo[2] ?? null,
                'NAMAKOTA'    => $clubInfo[3] ?? null,
                'KDJENISDOM'  => $domInfo[0] ?? null,
                'JENISDOM'    => $domInfo[1] ?? null,
                'KDPROPDOM'   => '05',
                'NAMAPROPDOM' => 'JAWA TIMUR',
                'KDKOTADOM'   => $domInfo[2] ?? null,
                'NAMAKOTADOM' => $validated['NAMAKOTADOM'],
                'STATUS'      => 1,
                'TGLDAFTAR'   => $today->toDateString(),
                'EXPIRED'     => $expired->toDateString(),
                'LASTMUTASI'  => $today->format('Ym'),
                'MUTASI'      => null,
            ]);
        });

        return redirect()->route('nias.index')
            ->with('success', 'Pendaftaran NIAS berhasil! Masa berlaku s/d: ' . $expired->format('d/m/Y'));
    }

    // -------------------------------------------------------------------------
    // SHOW
    // -------------------------------------------------------------------------
    public function show(Nias $nias)
    {
        $this->authorizeNias($nias);
        return view('nias.show', compact('nias'));
    }

    // -------------------------------------------------------------------------
    // EDIT
    // -------------------------------------------------------------------------
    public function edit(Nias $nias)
    {
        $this->authorizeNias($nias);

        $clubs     = array_keys(Nias::$clubLookup);
        sort($clubs);
        $domisilis = array_keys(Nias::$domisiliLookup);
        sort($domisilis);

        return view('nias.edit', compact('nias', 'clubs', 'domisilis'));
    }

    // -------------------------------------------------------------------------
    // UPDATE
    // -------------------------------------------------------------------------
    public function update(Request $request, Nias $nias)
    {
        $this->authorizeNias($nias);

        $validated = $request->validate([
            'NAMA'        => 'required|string|max:100',
            'GENDER'      => 'required|in:L,P',
            'TGLLAHIR'    => 'required|date|before:today',
            'TEMPATLAHIR' => 'required|string|max:100',
            'NIK'         => 'nullable|digits:16',
            'EMAIL'       => 'nullable|email|max:100',
            'NAMACLUB'    => 'required|string|max:100',
            'NAMAKOTADOM' => 'required|string|max:100',
        ]);

        $clubInfo = Nias::$clubLookup[$validated['NAMACLUB']] ?? null;
        $clubCode = Nias::$clubCodeLookup[$validated['NAMACLUB']] ?? null;
        $domInfo  = Nias::$domisiliLookup[$validated['NAMAKOTADOM']] ?? null;

        $nias->update([
            'NAMA'        => strtoupper(trim($validated['NAMA'])),
            'GENDER'      => $validated['GENDER'],
            'TGLLAHIR'    => $validated['TGLLAHIR'],
            'TEMPATLAHIR' => strtoupper(trim($validated['TEMPATLAHIR'])),
            'NIK'         => $validated['NIK']   ?? null,
            'EMAIL'       => $validated['EMAIL'] ?? null,
            'NAMACLUB'    => $validated['NAMACLUB'],
            'KDCLUB'      => $clubCode,
            'KDJENIS'     => $clubInfo[0] ?? null,
            'JENIS'       => $clubInfo[1] ?? null,
            'KDKOTA'      => $clubInfo[2] ?? null,
            'NAMAKOTA'    => $clubInfo[3] ?? null,
            'KDJENISDOM'  => $domInfo[0] ?? null,
            'JENISDOM'    => $domInfo[1] ?? null,
            'KDKOTADOM'   => $domInfo[2] ?? null,
            'NAMAKOTADOM' => $validated['NAMAKOTADOM'],
            'MUTASI'      => 'P',
            'LASTMUTASI'  => now()->format('Ym'),
        ]);

        return redirect()->route('nias.show', $nias)
            ->with('success', 'Data NIAS berhasil diperbarui.');
    }

    // -------------------------------------------------------------------------
    // DESTROY
    // -------------------------------------------------------------------------
    public function destroy(Nias $nias)
    {
        $this->authorizeNias($nias);
        $nias->delete();

        return redirect()->route('nias.index')
            ->with('success', 'Data NIAS berhasil dihapus.');
    }

    // -------------------------------------------------------------------------
    // HELPER — tolak akses kalau bukan punya user ini
    // -------------------------------------------------------------------------
    private function authorizeNias(Nias $nias): void
    {
        if ($nias->user_id !== Auth::id()) {
            abort(403, 'Kamu tidak punya akses ke data ini.');
        }
    }
}
